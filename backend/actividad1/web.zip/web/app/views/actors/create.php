<?php
require_once __DIR__ . '/../top.php';

?>
<div class="d-flex justify-content-center">

    <?php
    require_once __DIR__ . '/form.php';

    ?>
</div>


<?php
require_once __DIR__ . '/../bottom.php';
?>