<?php
class NotFoundException extends Exception {}
