<?php
class ValidationException extends Exception {}
