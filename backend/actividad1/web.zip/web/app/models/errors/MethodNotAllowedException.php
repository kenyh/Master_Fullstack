<?php
class MethodNotAllowedException extends Exception {}
